var builder = WebApplication.CreateBuilder(args);
var app = builder.Build();

//1. Logging Middleware
app.Use(async (context, next) =>
{
    Console.WriteLine($"Request: {context.Request.Method} {context.Request.Path}");

    await next();

    Console.WriteLine($"Response Status: {context.Response.StatusCode}");
});

//2. Error Handling Middleware
app.UseExceptionHandler("/error");

app.Map("/error", (HttpContext context) =>
{
    return Results.Text("Custom Error: Something went wrong!");
});

//3. HTTPS Redirection
app.UseHttpsRedirection();

//4. Security Headers (CSP)
app.Use(async (context, next) =>
{
    context.Response.Headers.Add(
        "Content-Security-Policy",
        "default-src 'self'; script-src 'self'; style-src 'self';"
    );

    await next();
});

//5. Static Files
app.UseStaticFiles();

//Default Route
app.MapGet("/", () => "Middleware App Running!");

app.Run();