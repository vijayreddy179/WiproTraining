namespace RazorApp.Models
{
    public static class ItemStore
    {
        public static List<string> Items = new List<string>
        {
            "Item1",
            "Item2"
        };
    }
}