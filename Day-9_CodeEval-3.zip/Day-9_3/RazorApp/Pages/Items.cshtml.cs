using Microsoft.AspNetCore.Mvc.RazorPages;
using RazorApp.Models;

namespace RazorApp.Pages
{
    public class ItemsModel : PageModel
    {
        public List<string> Items { get; set; }

        public void OnGet()
        {
            Items = ItemStore.Items;
        }
    }
}