// Selecting DOM elements
const fetchBtn = document.getElementById('fetch-users');
const userContainer = document.getElementById('user-cards');

// Arrow function to fetch users
const fetchUsers = async () => {
    try {
        const response = await fetch('https://jsonplaceholder.typicode.com/users');
        const users = await response.json();

        // Using destructuring + template literals
        const userCards = users.map(({ id, name, email, phone, company }) => `
            <div class="user-card">
                <h3>${name}</h3>
                <p><strong>ID:</strong> ${id}</p>
                <p><strong>Email:</strong> ${email}</p>
                <p><strong>Phone:</strong> ${phone}</p>
                <p><strong>Company:</strong> ${company.name}</p>
            </div>
        `).join('');

        userContainer.innerHTML = userCards;

    } catch (error) {
        userContainer.innerHTML = `<p>Error fetching users!</p>`;
        console.error(error);
    }
};

// Add event listener
fetchBtn.addEventListener('click', fetchUsers);